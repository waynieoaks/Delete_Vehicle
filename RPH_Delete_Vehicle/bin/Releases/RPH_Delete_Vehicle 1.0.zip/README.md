# RPH Delete Vehicle by Waynieoaks
https://github.com/waynieoaks/RPH_Delete_Vehicle

Simple plugin to delete the closest vehicle in GTA 5.

Allows you to stand next to a vehicle and press a key to delete it. 
Includes optional protection flags for:
- The current vehicle you are sitting in
- The last vehicle you were sitting in
- Emergency vehicles

Installation: 
1. Copy the plugins folder into your "Grand Theft Auto V" install folder 
2. Edit the keybindings in the .ini to meet your requirements

Planned features:
- Prompt "are you sure" for protected vehicles allowing deletion override 

Version history: 
1.0.0
- Initial release
